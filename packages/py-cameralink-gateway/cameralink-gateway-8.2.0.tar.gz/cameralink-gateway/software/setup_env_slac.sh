##################################
# Setup environment
##################################
source /afs/slac.stanford.edu/g/reseng/vol31/anaconda/anaconda3/etc/profile.d/conda.sh

##################################
# Activate Rogue conda Environment
##################################
conda activate rogue_v5.10.0
#conda activate rogue_v5.18.4
