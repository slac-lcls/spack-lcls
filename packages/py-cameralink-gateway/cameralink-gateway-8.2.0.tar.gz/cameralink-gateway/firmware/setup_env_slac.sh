# Setup the Xilinx software and licensing
source /afs/slac.stanford.edu/g/reseng/xilinx/vivado_2020.1/Vivado/2020.1/settings64.sh
