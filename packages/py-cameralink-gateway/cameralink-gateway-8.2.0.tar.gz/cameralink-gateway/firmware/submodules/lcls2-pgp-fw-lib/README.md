# lcls2-pgp-fw-lib

LCLS2 PGP Firmware Library

# Clone the GIT repository

```$ git clone --recursive git@github.com:slaclab/lcls2-pgp-fw-lib```
