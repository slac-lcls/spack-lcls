
from distutils.core import setup
from git import Repo

repo = Repo()

# Get version before adding version file
ver = repo.git.describe('--tags')
ver = ver.replace('-', '+', 1) # https://github.com/pypa/setuptools/issues/3772

# append version constant to package init
with open('python/lcls2_pgp_fw_lib/__init__.py','a') as vf:
    vf.write(f'\n__version__="{ver}"\n')

setup (
   name='lcls2_pgp_fw_lib',
   version=ver,
   packages=['lcls2_pgp_fw_lib',
             'lcls2_pgp_fw_lib/shared',],
   package_dir={'':'python'},
)

