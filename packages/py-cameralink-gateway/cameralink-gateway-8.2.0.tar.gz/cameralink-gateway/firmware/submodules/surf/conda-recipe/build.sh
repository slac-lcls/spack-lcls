#!/usr/bin/bash

$PYTHON -m pip install .

