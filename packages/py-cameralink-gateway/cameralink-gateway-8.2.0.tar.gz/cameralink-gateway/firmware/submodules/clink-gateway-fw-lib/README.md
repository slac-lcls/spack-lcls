# clink-gateway-fw-lib

https://confluence.slac.stanford.edu/display/AIRTRACK/PC_248_100_22_C01
